package logicaJuego;

/**
 * Clase que modela el nivel 2 del juego.
 */
public class Nivel2 extends Nivel {
	protected final int cantidadEnemigosOleada = 20;

	/**
	 * Constructor del nivel.
	 * @param juego Juego.
	 */
	public Nivel2(Juego juego) {
		super(juego);
		this.siguienteNivel = null;
		this.armarOleadas(cantidadEnemigosOleada);
	}

	@Override
	public Nivel getSiguienteNivel() {
		return this.siguienteNivel;
	}

}