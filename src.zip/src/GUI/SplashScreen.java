package GUI;

import javax.swing.JWindow;

public class SplashScreen extends JWindow {

	

	
}
