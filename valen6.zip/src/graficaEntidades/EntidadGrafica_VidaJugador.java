package graficaEntidades;

import javax.swing.ImageIcon;

public class EntidadGrafica_VidaJugador extends EntidadGrafica {
	
	/**
	 * Constructor de la entidad gráfica de la vida del jugador.
	 */
	public EntidadGrafica_VidaJugador(int x,int y) {
		super();
		ImageIcon imageIcon = new ImageIcon(this.getClass().getResource("/IMG/corazon_sinvida.png"));
		acomodarEtiqueta(x,y);
		this.etiqueta.setIcon(imageIcon);
		imageIcon.setImageObserver(this.etiqueta);
		this.etiqueta.repaint();
	}
	
	@Override
	public void acomodarEtiqueta(int x, int y) {
		this.etiqueta.setBounds(x,y,25,25);
	}

	@Override
	public void modificarEtiqueta() {}
	
	/**
	 * Modifica la imagen agregándole vida.
	 */
	public void agregarVida() {
		ImageIcon imageIcon = new ImageIcon(this.getClass().getResource("/IMG/corazon.png"));
		getJLabel().setIcon(imageIcon);
		getJLabel().repaint();
	}
	
	/**
	 * Modifica la imagen sacandole vida.
	 */
	public void sacarVida() {
		ImageIcon imageIcon = new ImageIcon(this.getClass().getResource("/IMG/corazon_sinvida.png"));
		getJLabel().setIcon(imageIcon);
		getJLabel().repaint();
	}

}
