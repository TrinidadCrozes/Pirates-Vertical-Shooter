package logicaJuego;

import java.awt.event.KeyEvent;

import logicaEntidades.Entidad;
import movimientoEntidades.Movimiento;

public class MenteTeclado {

	/**
	 * Mueve al jugador.
	 * @param key Tecla apretada.
	 */
	public void mover(int key, Juego juego) { 
		Entidad proyectil;
		Movimiento mov_jugador = juego.getJugador().getMovimiento();
		switch(key) {
			case KeyEvent.VK_LEFT: {
					mov_jugador.moverIzquierda();
				break;
			}
			case KeyEvent.VK_RIGHT: {
					mov_jugador.moverDerecha();
				break;
			}
			case KeyEvent.VK_SPACE: {
				if (juego.getEsperarDisparo() <= 0) {
					juego.setEsperarDisparo(10);
					proyectil = mov_jugador.atacar();
					juego.agregarObjeto(proyectil);
				}
				break;
			}
		}
		
		juego.getJugador().getEntidadGrafica().getJLabel().setLocation(juego.getJugador().getMovimiento().getPosicion());
		
	}
	
	
}
