package audio;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.Player;

public class Musica implements Runnable {
	protected final Player player;

	public Musica() throws FileNotFoundException, JavaLayerException {
		player = new Player(new FileInputStream("src\\audio\\cancion.mp3"));
	}

	@Override
	public void run() {
		try {
			while (true) {
				player.play();
			}
		} catch (JavaLayerException e) {
			e.printStackTrace();
		}
	}
	
	public void stop() {
		player.close();
	}
}