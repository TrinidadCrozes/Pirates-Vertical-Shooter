package GUI;

import javax.swing.JLabel;

/**
 * Clase que modela gráficas del juego.
 */
public abstract class Grafica {
	protected JLabel etiqueta;
	
	/**
	 * Constructor de la gráfica.
	 */
	public Grafica() {
		this.etiqueta = new JLabel();
	}
	
	/**
	 * Retorna el JLabel.
	 * @return JLabel.
	 */
	public JLabel getJLabel() {
		return this.etiqueta;
	}
	
	/**
	 * Acomoda la etiqueta en la ubicación que especifica.
	 * @param x Posicion x.
	 * @param y Posicion y.
	 */
	public abstract void acomodarEtiqueta(int x, int y);
	
}
