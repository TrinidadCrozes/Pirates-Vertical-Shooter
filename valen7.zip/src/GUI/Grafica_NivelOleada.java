package GUI;



import javax.swing.ImageIcon;

/**
 * Clase que modela la gráfica del nivel y oleada.
 */
public class Grafica_NivelOleada extends Grafica {
	
	/**
	 * Constructor de la gráfica Nivel Oleada.
	 * @param x Posición x.
	 * @param y Posición y.
	 * @param imagen Ruta de la imagen.
	 */
	public Grafica_NivelOleada(int x, int y, String imagen) {
		super();
		ImageIcon imagenNivel = new ImageIcon(this.getClass().getResource(imagen));
		this.etiqueta.setIcon(imagenNivel);
		acomodarEtiqueta(x,y);
	}
	
	@Override
	public void acomodarEtiqueta(int x, int y) {
		etiqueta.setBounds(x, y,100,50);
	}

	/**
	 * Modifica la etiqueta.
	 */
	public void modificarEtiqueta(String imagen) {
		ImageIcon imagenNivel = new ImageIcon(this.getClass().getResource(imagen));
		this.etiqueta.setIcon(imagenNivel);
	}

}
